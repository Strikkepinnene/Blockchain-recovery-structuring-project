# Blockchain Recovery Structuring Project

## Norsk

**Hensikt:**  
Dette prosjektet er opprettet for å strukturere og dokumentere prosessen med å gjenopprette blokkjede-midler, med særlig fokus på å gi noe tilbake til de utviklerne og bidragsyterne som har lagt grunnlaget for hele økosystemet. Dette skjer i form av bounties for oppnåelser og bidrag.

**Evalueringsperiode:**  
Kandidater vurderes løpende, men en evalueringsstrek settes **31. august 2025**.

**Kontakt:**  
block.recovery.bounty@proton.me

---

## English

**Purpose:**  
This project has been created to structure and document the process of recovering blockchain assets, with a particular focus on giving back to the developers and contributors who have laid the foundation for the entire ecosystem. This will be done through bounties for achievements and contributions.

**Evaluation period:**  
Candidates will be evaluated on a rolling basis, with a final review deadline on **August 31, 2025**.

**Contact:**  
block.recovery.bounty@proton.me
