# Prosjektbakgrunn

Dette dokumentet beskriver bakgrunnen for prosjektet, koblingen til 'The Social Node', og hvordan midlene fra blokkjedegjenvinning skal fordeles.