# The Social Node

Dette dokumentet beskriver konseptet 'The Social Node', som en modell for å reinvestere deler av midler til samfunnsnyttige formål.