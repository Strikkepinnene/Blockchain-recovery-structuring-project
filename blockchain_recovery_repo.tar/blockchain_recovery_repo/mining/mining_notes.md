# Mining

Denne mappen skal inneholde dokumentasjon og scripts relatert til mining og gjenvinning av historiske blokker.