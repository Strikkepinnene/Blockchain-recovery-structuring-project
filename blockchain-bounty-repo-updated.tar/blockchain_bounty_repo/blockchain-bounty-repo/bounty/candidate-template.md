# Candidate Proposal Template

**Name:**  
**Contribution Area:**  
**Details of Work:**  
**Requested Bounty Amount:**  

