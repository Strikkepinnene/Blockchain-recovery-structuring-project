# The Social Node Vision

A decentralised mechanism to reinvest blockchain-derived resources into public good: education, climate, research, and more.

