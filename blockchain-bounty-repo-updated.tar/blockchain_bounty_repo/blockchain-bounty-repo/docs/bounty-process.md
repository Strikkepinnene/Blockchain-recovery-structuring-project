# Bounty Process

- Candidates submit proposals in writing
- Evaluation will be ongoing until the cut-off date: **31.08.2025**
- Rewards distributed in crypto, sourced from blockchain-derived funds

